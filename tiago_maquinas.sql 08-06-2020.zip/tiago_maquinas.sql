-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 08/06/2020 às 21:49
-- Versão do servidor: 10.4.10-MariaDB
-- Versão do PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tiago_maquinas`
--
CREATE DATABASE IF NOT EXISTS `tiago_maquinas` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tiago_maquinas`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoria`
--

DROP TABLE IF EXISTS `categoria`;
CREATE TABLE IF NOT EXISTS `categoria` (
  `id_categoria` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` varchar(20) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `sobrenome` varchar(50) NOT NULL,
  `telefone_1` varchar(20) NOT NULL,
  `telefone_2` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `rua` varchar(100) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `complemento` varchar(50) DEFAULT NULL,
  `bairro` varchar(50) NOT NULL,
  `cidade` varchar(50) DEFAULT NULL,
  `cep` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `cpf`, `nome`, `sobrenome`, `telefone_1`, `telefone_2`, `email`, `rua`, `numero`, `complemento`, `bairro`, `cidade`, `cep`) VALUES
(1, '03689043697', 'ADILSON', 'DONIZETE FERREIRA ', '35920004992', '0', 'thirso@live.com', 'OSVALDO S ANJOS ', '168', '', 'CERRADO', 'ITAMOGI', '37973000'),
(18, '373.669.938-75', 'FERNANDO', 'HENRIQUE MARTIHS', '(16)99965-0669', '(16)99965-0669', '', 'SITIO POSSAO', 'S/N', '', 'ZONA RURAL', 'SANTO ANTONIO ALEGRIA', '14990000'),
(3, '343.134.468-26', 'CELSO', 'DA COSTA PIRES', '(16)99715-5355', '(  )     -', '', 'FAZENDA PAGA PAU', '00', '', '', 'ALTINOPOLIS', '00000'),
(4, '005.905.356-92', 'MARCOS', 'ANTONIO CHAGAS', '(35)98928-22', '(85)25295-202', '', 'JUCELINO KUBITSCHEK', '163', '', 'CENTRO', 'ITAMOGI', '37973000'),
(5, '238.319.956-72', 'FAUSTO', 'JOSE DE SOUZA', '(16)99751-4971', '(16)99751-4971', '', 'SITIO BAU', 'S/N', '', 'ZONA RURAL', 'MONTE SANTO DE MINAS', '365225225'),
(6, '130.308.526-79', 'JONATHAS', 'DE JESUS SILVA', '(35)99710-9517', '(35)99710-9517', '', 'SITIO SERRINHA DA BELA VISTA', 'S/N', '', '', 'ITAMOGI', '37973000'),
(7, '525.656.633-2', 'JOSE ', 'DONIZETE DO CARMO', '(35)99958-5352', '(35)99958-5352', '', 'BARAO DO RIO BRANCO', '230', '', 'CENTRO', 'ITAMOGI', '37973000'),
(8, '531.310.706-25', 'ANTONIO', 'DONIZETE MEDEIROS', '(35)99742-2128', '(35)99742-2128', '', 'SITIO CANDINHOS', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(9, '110.762.216-61', 'MARCOS', 'ROBERTO FORNANZIERI SILVA', '(35)99038-712', '(35)99038-712', '', 'FAZENDA SERRA', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(10, '049.063.946-12', 'VILMA', 'SIMONI', '(35)99846-4148', '(35)99846-4148', '', 'SITIO 2 IRMAOS', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(11, '121.121.121-12', 'CONSUMIDOR', 'CONSUMIDOR', '(35) 3535-2525', '(35) 3535-2525', '', 'WENCESLAU BRAS', '183', '', '', 'ITAMOGI', '3797300'),
(12, '26281700864', 'DARCI', 'LUIZ CARVALHO', '35999761996', '35999761996', '', 'SITIO 3 PODER', 'S/N', '', 'MORRO VERMELHO', 'ITAMOGI', '37973000'),
(13, '461.831.326-91', 'PIO', 'MARTINS DOMINGOS', '(35)99752-9271', '(35)99752-9271', '', 'SITIO PINHERINHO', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(14, '050.387.536-80', 'HERBIO', 'DONIZETE GOLCALVES DE MEDEIROS', '(35)99821-1676', '(35)99821-1676', '', 'DOS MORAES', '775', '', 'VALE DO SOL', 'ITAMOGI', '37973000'),
(15, '949.320.506-15', 'JOAO ', 'BATISTA NAVES ', '(35)99826-4290', '(  )     -', '', 'JOAO EVANGELISTA SOARES', '937', '', 'VALE DO SOL ', 'ITAMOGGI ', '37973000'),
(16, '850.805.786-53', 'DAGUIMAR', 'JOSE DA SILVA', '(35)99911-8471', '(95)99911-8471', '', 'NOSSA SENHORA ', '250', '', 'CERRADO', 'ITAMOGI', '37973000'),
(17, '030.807.866-70', 'EDSON', 'SANTANA', '(35)99824-0147', '(35)99824-0147', '', 'OVIDIO DE ABREU', '780', '', 'CENTRO', 'ITAMOGI', '37973000'),
(19, '066.230.386-55', 'EDGAR', 'GOMES DE FREITAS', '(35)99815-0011', '(35)99815-0011', '', 'ANTONIO BERTELI', '165', '', 'LAGO AZUL', 'ITAMOGI', '37973000'),
(20, '019.816.448-30', 'JOSE ', 'CARLOS CARDEAL', '(16)99996-7073', '(16)36681-278', '', 'JOAO BATISTA GARCIA', '10', '', 'CENTRO', 'SANTO ANTONIO DA ALEGRIA', '14390000'),
(21, '073.957.116-88', 'VAGUINER', 'JUNIOR DOMIGOS', '(35)99988-8973', '(35)99988-8973', '', 'SITIO PINHERINHO', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(22, '000.000.000-00', 'RONALDO', 'PEREIRA DIAS', '(35)35341-378', '(35)35341-378', '', 'FAZENDA RIBEIRAO DAS PEDRAS', 'S/N', '', '', 'ITAMOGI', '37973000'),
(23, '100.822.116-39', 'VANDO', ' MIGUEL SOUZA', '(35)99839-0623', '(35)99839-0623', '', 'SITIO CANDINHOS', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(24, '811.733.696-00', 'LUIZ', 'ANTONIO PEREIRA', '(35)99943-1130', '(35)99943-1130', '', 'SITIO LAGOA', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(25, '389.721.746-53', 'DIVINO', 'GARCIA MAIA', '(16)99965-7898', '(16)99965-7898', '', 'SITIO PIQUI 1', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '14390000'),
(26, '005.905.356-92', 'MARCOS', 'ANTONIO CHAGAS', '(35)99952-7475', '(35)99952-7475', '', 'JUCELINO KUBICHEQUE', '163', '', 'BOM JESSUS', 'ITAMOGI', '37973000'),
(27, '   .   .   -', 'DOUGUAS', 'DONIZETE DE OLIVEIRA', '(35)99903-9775', '(35)99903-9975', '', 'SITIO PEROBAS', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '37973000'),
(28, '049.552.086-14', 'CLAUDIO', 'REIS DE SOUSA', '(35)99829-2819', '(35)99829-2819', '', 'ANTONIO DE PADUA DIAS', '519', '', 'JARDIM UNIAO 2', 'ITAMOGI', '37973000'),
(29, '756.824.506-91', 'LUIS', ' MARCIO BERNARDO', '(35)99840-9937', '(  )     -', '', 'OTAIR MARTINS', '38', '', 'CERRADO', 'ITAMOGI', '37973000'),
(30, '050.189.566-31', 'ANTONIO', 'APARECIDO NAVES', '(35)35352-5526', '(  )     -', '', 'TOMAS MANUEL SOARES', '260', '', 'ALTO APARECIDA', 'ITAMOGI', '37973000'),
(31, '   .   .   -', 'ALEXANDRE', ' OLIVEIRA PEREIRA', '(35)99879-6972', '(  )     -', '', 'ALEXANDRE RAMOS LEMOS ', '124', '', 'LAGO AZUL', 'ITAMOGI', '37973000'),
(32, '093.351.606-10', 'RONIVALDO ', ' FERNANDES PESSOA', '(35)99895-9652', '(  )     -', '', 'SITIO VIDIGAL', 'S/N', '', '', 'ITAMOGI ', '37973000'),
(33, '   .   .   -', 'HIGO', 'SILVA NEVES', '(35)99895-1741', '(  )     -', '', 'ADELINA ROSA PEREIRA', '128', '', 'SAO JOAO BATISTA ', 'ITAMOGI ', '37973000'),
(34, '811.734.906-04', 'JOAO', 'BATISTA ROSA', '(35)35341-525', '(35)35341-52', '', 'SITIO LAGOA', 'S/N', '', 'ZONA RURAL', 'ITAMOGI', '3797300 '),
(35, '002.779.938-73', 'ORLANDIRO ', 'CORREIA SE SOUZA', '(16)99966-1551', '(16)99966-1551', '', 'SITIO CAPIVARA', 'S/N', '', 'ZONA RURAL', 'SANTO ANTONIO DA ALEGRIA', '14390000');

-- --------------------------------------------------------

--
-- Estrutura para tabela `fornecedores`
--

DROP TABLE IF EXISTS `fornecedores`;
CREATE TABLE IF NOT EXISTS `fornecedores` (
  `id_fornecedor` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cnpj` bigint(20) DEFAULT NULL,
  `nome` varchar(25) NOT NULL,
  `telefone1` int(11) UNSIGNED NOT NULL,
  `telefone_2` int(11) UNSIGNED DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `rua` varchar(100) DEFAULT NULL,
  `numero` varchar(10) DEFAULT NULL,
  `complemento` varchar(50) DEFAULT NULL,
  `bairro` varchar(50) DEFAULT NULL,
  `cidade` varchar(50) DEFAULT NULL,
  `cep` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id_fornecedor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `fornecedores_produtos`
--

DROP TABLE IF EXISTS `fornecedores_produtos`;
CREATE TABLE IF NOT EXISTS `fornecedores_produtos` (
  `id_fornecedor` int(11) UNSIGNED NOT NULL,
  `id_categoria` int(10) UNSIGNED NOT NULL,
  `id_produto` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_fornecedor`,`id_categoria`,`id_produto`),
  KEY `fornecedores_has_produtos_FKIndex1` (`id_fornecedor`),
  KEY `fornecedores_has_produtos_FKIndex2` (`id_produto`,`id_categoria`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `fornecedores_servicos`
--

DROP TABLE IF EXISTS `fornecedores_servicos`;
CREATE TABLE IF NOT EXISTS `fornecedores_servicos` (
  `id_fornecedor` int(11) UNSIGNED NOT NULL,
  `id_servico` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_fornecedor`,`id_servico`),
  KEY `fornecedores_has_servicos_FKIndex1` (`id_fornecedor`),
  KEY `fornecedores_has_servicos_FKIndex2` (`id_servico`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_venda`
--

DROP TABLE IF EXISTS `itens_venda`;
CREATE TABLE IF NOT EXISTS `itens_venda` (
  `id_item` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_venda` int(11) UNSIGNED NOT NULL,
  `id_produto` int(11) UNSIGNED NOT NULL,
  `id_categoria` int(10) UNSIGNED NOT NULL,
  `num_item` int(11) UNSIGNED NOT NULL,
  `qtde` int(10) UNSIGNED DEFAULT NULL,
  `total_item` double(6,2) DEFAULT NULL,
  PRIMARY KEY (`id_item`,`id_venda`,`id_categoria`,`id_produto`),
  KEY `itens_venda_FKIndex1` (`id_venda`),
  KEY `itens_venda_FKIndex2` (`id_produto`,`id_categoria`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `orcamentos`
--

DROP TABLE IF EXISTS `orcamentos`;
CREATE TABLE IF NOT EXISTS `orcamentos` (
  `id_orcamento` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `data_hora` datetime NOT NULL DEFAULT current_timestamp(),
  `equipamento` varchar(50) CHARACTER SET utf8 NOT NULL,
  `marca` varchar(50) CHARACTER SET utf8 NOT NULL,
  `modelo` varchar(50) CHARACTER SET utf8 NOT NULL,
  `defeito` text CHARACTER SET utf8 NOT NULL,
  `observacao` text CHARACTER SET utf8 DEFAULT NULL,
  `valor_total` decimal(6,2) DEFAULT NULL,
  `status` varchar(25) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_orcamento`,`id_usuario`,`id_cliente`),
  KEY `orcamentos_FKIndex1` (`id_usuario`),
  KEY `orcamentos_FKIndex2` (`id_cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `orcamentos`
--

INSERT INTO `orcamentos` (`id_orcamento`, `id_usuario`, `id_cliente`, `data_hora`, `equipamento`, `marca`, `modelo`, `defeito`, `observacao`, `valor_total`, `status`) VALUES
(1, 1, 1, '2020-05-27 13:11:51', 'ROÇADEIRA ', 'STHILL', '85', 'NÃO LIGA', 'FICOU PARADA UM ANO', '300.88', 'Análise'),
(2, 1, 1, '2020-05-27 13:33:39', 'gggg', 'gggggg', 'ggg', 'gggg', 'ggg', '10.97', 'Análise'),
(3, 1, 1, '2020-05-27 13:34:42', 'HHHHH', 'HHH', 'HHH', 'HHH', 'HH', '50.97', 'Análise'),
(4, 1, 1, '2020-05-27 13:43:16', 'SOPRADOR ', 'STHILL', '85', 'NÃO LIGA ', 'FICOU PARADO', '174.85', 'Análise'),
(5, 1, 1, '2020-05-27 14:01:45', 'ROCADEIRA', 'STIHL', '85', 'NAO PEGA', 'NAO LIGA', '117.00', 'Análise'),
(6, 1, 1, '2020-05-27 14:42:15', 'IMPLEMENTO SP ', 'STIHL', 'SP', 'GRAXA', 'SEM GRAXA', '45.00', 'Análise'),
(7, 1, 1, '2020-05-27 17:58:37', 'SOPRADOR', 'MM', 'MMM', 'NAO LIGA', '', '0.00', 'Análise'),
(8, 1, 5, '2020-05-28 14:29:19', 'MOTOSERRA', 'HUSQVARNA', '268', 'ESTA FROUXA', '', '0.00', 'Análise'),
(9, 1, 7, '2020-05-28 16:49:17', 'ROCADEIRA', 'STIHL', '85', 'TA FROUXA', 'LIMPEZA', '0.00', 'Análise'),
(10, 1, 9, '2020-05-28 17:48:19', 'ROÇADEIRA', 'STIHL', 'KA 85', 'CARBURADOR', 'NAO PEGA', '0.00', 'Análise'),
(11, 1, 10, '2020-05-29 09:16:37', 'ROÇADEIRA', 'STIHL', 'KA 85', 'REVISAO', '', '0.00', 'Análise'),
(12, 1, 11, '2020-05-29 09:23:06', 'ROCADEIRA', 'STIHL', 'KA 85', 'REVISAO', '', '0.00', 'Análise'),
(13, 1, 12, '2020-05-29 09:53:48', 'ROÇADEIRA', 'TU 26', 'TU26', 'REVISAO ', '', '0.00', 'Análise'),
(14, 1, 13, '2020-05-29 10:00:30', 'ROÇADEIRA', 'HUSQVARNA', '226RJ', 'COLOCAR MAOZINHA', '', '0.00', 'Análise'),
(15, 1, 11, '2020-05-29 12:16:48', 'ROCADEIRA', 'HUSQVARNA', '226', 'DESCARBONIZACAO', '', '12.00', 'Análise'),
(16, 1, 11, '2020-05-29 14:27:13', 'ROCADEIRA', 'SHINDAIWA', 'C 230', 'MOLA', '', '5.90', 'Análise'),
(17, 1, 1, '2020-05-29 18:10:55', 'motoserra', 'marca ', 'marca', 'nao liga ', 'ficou parada ', '212.00', 'Análise'),
(18, 1, 1, '2020-05-29 18:21:28', 'teste ', 'teste ', 'teste', ' teste ', '', '239.90', 'Análise'),
(19, 1, 15, '2020-06-01 08:22:20', 'rocadeira', 'stihl', 'ka 85', 'NAO PEGA', '', '70.00', 'Análise'),
(20, 1, 17, '2020-06-01 14:37:56', 'ROCADEIRA', 'STIHL', '85', 'TRCAR CANO', '', '75.00', 'Análise'),
(21, 1, 11, '2020-06-02 10:02:35', 'MAOZINHA', 'BRUDDEN', 'C230', 'TRCAR PINHAO', '', '104.00', 'Análise'),
(22, 1, 18, '2020-06-02 12:26:38', 'SOPRADOR', 'STIHL', 'BG 85', 'NAO AFRMA', '', '0.00', 'Análise'),
(23, 1, 11, '2020-06-02 14:21:09', 'KA ', 'STIHL', '85', 'TRASMISAO', '', '150.00', 'Análise'),
(24, 1, 20, '2020-06-02 16:21:12', 'ROCADEIRA', 'GH', '52', 'BOIA', '', '0.00', 'Análise'),
(25, 1, 21, '2020-06-02 18:21:03', 'ROCADEIRA', 'HUSQVARNA', '226', 'CILINDRO', '', '365.00', 'Análise'),
(26, 1, 22, '2020-06-03 14:56:33', 'SOPRADOR', 'STIHL', 'BR 600', 'CARBURADOR NOVO', '', '273.00', 'Análise'),
(27, 1, 23, '2020-06-03 20:07:57', 'ROÇADEIRA ', 'STHIL', '85R', 'REVISAO', '', '0.00', 'Análise'),
(28, 1, 24, '2020-06-04 09:56:22', 'ROCADEIRA', 'STIHL', '85', 'LIMPAR CARBURADOR', '', '162.00', 'Análise'),
(29, 1, 11, '2020-06-04 12:29:53', 'ROCADEIRA', 'STIHL', '85', 'REVISAO', '', '0.00', 'Análise'),
(30, 1, 11, '2020-06-04 14:57:33', 'ROCADEIRA', 'HUSQVARNA', '226', 'TROCAR CANO', '', '728.50', 'Análise'),
(31, 1, 11, '2020-06-04 16:23:24', 'IMPLEMENTO ', 'BRUDDEN', 'C230', 'TROCAR GABINETE', '', '120.00', 'Análise'),
(32, 1, 25, '2020-06-04 17:34:24', 'IMPLEMENTO', 'BRUDDEN', 'C 230', 'TROCAR GABINETE', '', '120.00', 'Análise'),
(33, 1, 11, '2020-06-05 10:05:56', 'SOPRADOR', 'STIHL', 'BR 420', 'LIMPEZA CARBURADOR', '', '135.00', 'Concluido'),
(34, 1, 27, '2020-06-05 11:54:51', 'ROCADEIRA', 'HUSQVARNA', '226', 'TUBO DO EIXO', '', '180.00', 'Análise'),
(35, 1, 28, '2020-06-05 13:30:18', 'ROCADEIRA', 'HUSQVARNA', '226', 'ROLAMENTO', '', '59.00', 'Análise'),
(36, 1, 29, '2020-06-05 14:42:16', 'ROÇADEIRA', 'HUQVARNA', '226', 'ORÇAMENTO', '', '0.00', 'Análise'),
(37, 1, 35, '2020-06-06 08:31:48', 'SOPRADOR', 'BRANCO', 'BRANCO', 'NAO AFIRMA', '', '0.00', 'Análise'),
(38, 1, 11, '2020-06-06 11:59:09', 'VENTOSA', 'VENTOSA', '65', 'VENTOSA', '', '13.00', 'Análise');

-- --------------------------------------------------------

--
-- Estrutura para tabela `ordem_servico`
--

DROP TABLE IF EXISTS `ordem_servico`;
CREATE TABLE IF NOT EXISTS `ordem_servico` (
  `id_ordem_servico` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_orcamento` int(10) UNSIGNED NOT NULL,
  `_id_usuario` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_recebimento` int(11) UNSIGNED NOT NULL,
  `id_parcelamento` int(11) UNSIGNED NOT NULL,
  `data_hora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `aparelho` varchar(50) CHARACTER SET utf8 NOT NULL,
  `marca` varchar(50) CHARACTER SET utf8 NOT NULL,
  `modelo` varchar(50) CHARACTER SET utf8 NOT NULL,
  `defeito` text CHARACTER SET utf8 NOT NULL,
  `obsevacao` text CHARACTER SET utf8 DEFAULT NULL,
  `valor_total` double(6,2) NOT NULL,
  `data_entrega` date NOT NULL,
  `hora_entrega` time NOT NULL,
  `status` varchar(25) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_ordem_servico`,`id_orcamento`,`_id_usuario`,`id_cliente`,`id_usuario`,`id_recebimento`,`id_parcelamento`),
  KEY `ordem_servico_FKIndex1` (`id_orcamento`,`_id_usuario`,`id_cliente`),
  KEY `ordem_servico_FKIndex2` (`id_usuario`),
  KEY `ordem_servico_FKIndex3` (`id_recebimento`,`id_parcelamento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `parcelamento`
--

DROP TABLE IF EXISTS `parcelamento`;
CREATE TABLE IF NOT EXISTS `parcelamento` (
  `id_parcelamento` int(11) UNSIGNED NOT NULL,
  `num_parcelas` int(11) DEFAULT NULL,
  `valor_parcelas` double(6,2) DEFAULT NULL,
  `venc_1` date DEFAULT NULL,
  PRIMARY KEY (`id_parcelamento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
  `id_produto` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_categoria` int(10) UNSIGNED NOT NULL,
  `cod_barras` varchar(20) NOT NULL,
  `descricao` varchar(255) CHARACTER SET utf8 NOT NULL,
  `marca` varchar(50) CHARACTER SET utf8 NOT NULL,
  `unid_venda` varchar(15) CHARACTER SET utf8 NOT NULL,
  `preco_custo` decimal(8,2) NOT NULL,
  `preco_venda` decimal(8,2) NOT NULL,
  `desconto` double(8,2) NOT NULL,
  `estoque_min` int(11) NOT NULL,
  `localizacao` varchar(50) CHARACTER SET utf8 NOT NULL,
  `fornecedor_1` int(11) DEFAULT NULL,
  `fornecedor_2` int(11) DEFAULT NULL,
  `imagem` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_produto`) USING BTREE,
  KEY `produtos_FKIndex1` (`id_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id_produto`, `id_categoria`, `cod_barras`, `descricao`, `marca`, `unid_venda`, `preco_custo`, `preco_venda`, `desconto`, `estoque_min`, `localizacao`, `fornecedor_1`, `fornecedor_2`, `imagem`) VALUES
(1, 1, '0000', 'ABAFADOR K40', 'GENERICO', 'Unid', '10.97', '20.00', 0.00, 10, '00', 0, 0, ''),
(2, 1, '02', 'ACELERADOR COMPLETO C 230', 'SHINDAIWA', 'Unid', '117.00', '164.00', 0.00, 10, '2552', 0, 0, ''),
(3, 1, '000', 'GRAXA NA MAOZINHA', 'STIHL', 'Unid', '5.00', '25.00', 0.00, 10, '001', 0, 0, ''),
(4, 1, '001', 'AFOGADOR MS 61/268/272', 'HUSQVARNA', 'Unid', '1.50', '7.00', 0.00, 10, '00', 0, 0, ''),
(5, 1, '001', 'ALAVANCA DO ACELERADOR', 'STIHL', 'Unid', '5.00', '15.00', 0.00, 10, '001', 0, 0, ''),
(6, 1, '001', 'AMORTECEDOR  272', 'QUAQVARNA', 'Unid', '4.31', '15.00', 0.00, 10, '001', 0, 0, ''),
(7, 1, '001', 'AMORTECEDOR 272 PEQUENO', 'HUSQVARNA', 'Unid', '3.35', '15.00', 0.00, 10, '001', 0, 0, ''),
(8, 1, '001', 'AMORTECEDOR BOMBA  6.50', 'NOGUEIRA', 'Unid', '22.00', '48.00', 0.00, 10, '001', 0, 0, ''),
(9, 1, '001', 'AMORTECEDOR BOMBA 800/900', 'NOGUEIRA', 'Unid', '24.00', '48.00', 0.00, 10, '001', 0, 0, ''),
(10, 1, '001', 'AMORTECEDOR 226 RJ', 'HUSQVARNA', 'Unid', '11.90', '24.00', 0.00, 10, '001', 0, 0, ''),
(11, 1, '001', 'ANEL DE COMPRESAO 226 RJ', 'HUSQVARNA', 'Unid', '6.35', '19.00', 0.00, 10, '001', 0, 0, ''),
(12, 1, '001', 'ANEL BOMBA 650', 'NOGUEIRA', 'Unid', '3.50', '16.00', 0.00, 10, '001', 0, 0, ''),
(13, 1, '001', 'ANEL BOMBA 800/900', 'NOGUEIRA', 'Unid', '3.50', '16.00', 0.00, 10, '001', 0, 0, ''),
(14, 1, '001', 'ANEL VEDACAO RE 98/108', 'STIHL', 'Unid', '2.50', '4.00', 0.00, 10, '01', 0, 0, ''),
(15, 1, '001', 'ARRASTADOR 226 RJ (4882)', 'HUSQVARNA', 'Unid', '13.30', '20.00', 0.00, 10, '001', 0, 0, ''),
(16, 1, '001', 'ARRUELA DE ACO 272', 'HUSQVARNA', 'Unid', '1.90', '9.00', 0.00, 10, '01', 0, 0, ''),
(17, 1, '001', 'ARRUELA DE PLASTICO 272', 'HUSQUARNA', 'Unid', '1.75', '6.00', 0.00, 10, '001', 0, 0, ''),
(18, 1, '001', 'ARRULA LISA C230', 'SHINDAIWA', 'Unid', '3.39', '7.00', 0.00, 10, '01', 0, 0, ''),
(19, 1, '001', 'AVENTAL RASPA', 'COURO', 'Unid', '25.70', '48.00', 0.00, 10, '001', 0, 0, ''),
(20, 1, '001', 'BICO LEQUE AMARELA JACTO 2', 'JACTO', 'Unid', '2.70', '4.00', 0.00, 10, '01', 0, 0, ''),
(21, 1, '001', 'BICO LEQUE JACTO AMARELO PLASTICO 2', 'JACTO', 'Unid', '3.00', '6.00', 0.00, 10, '001', 0, 0, ''),
(22, 1, '001', 'BICO LEQUE VERMELHO JACTO 4', 'JACTO', 'Unid', '3.00', '7.00', 0.00, 10, '001', 0, 0, ''),
(23, 1, '001', 'BIELA DCM 12 BRUDDEN', 'BRUDDEN', 'Unid', '58.00', '110.00', 0.00, 10, '001', 0, 0, ''),
(24, 1, '001', 'BIELA P8 DCM 11 BRUDDEN', 'BRUDDEN', 'Unid', '54.01', '100.00', 0.00, 10, '001', 0, 0, ''),
(25, 1, '001', 'BOMBA NOGUEIRA 6.5', 'NOGUEIRA', 'Unid', '180.00', '298.00', 0.00, 10, '001', 0, 0, ''),
(26, 1, '001', 'BOMBA NOGUEIRA 900', 'NOGUEIRA', 'Unid', '197.00', '300.00', 0.00, 10, '001', 0, 0, ''),
(27, 1, '001', 'BOMBA DE OLEO 272', 'HUSQVARNA', 'Unid', '62.50', '135.00', 0.00, 10, '001', 0, 0, ''),
(28, 1, '001', 'BUCHA DO CANO 226RJ', 'HUSQVARNA', 'Unid', '95.00', '22.00', 0.00, 10, '001', 0, 0, ''),
(29, 1, '001', 'BUCHA CANO C230', 'SHINDAIWA', 'Unid', '8.10', '22.00', 0.00, 10, '001', 0, 0, ''),
(30, 1, '001', 'CABECOTE ASPIRACAO (415)', 'ANDRADAS', 'Unid', '4.50', '15.00', 0.00, 10, '001', 0, 0, ''),
(31, 1, '001', 'CABO ACELERADOR C230', 'SHINDAIWA', 'Unid', '6.00', '24.00', 0.00, 10, '001', 0, 0, ''),
(32, 1, '001', 'CABO ACELERADOR LONGO C230(478)', 'SHINDAIWA', 'Unid', '9.90', '48.90', 0.00, 10, '001', 0, 0, ''),
(33, 1, '001', 'CABO DO ACELERADOR FS 160 ANT(358)', 'STIHL', 'Unid', '8.50', '48.00', 0.00, 10, '001', 0, 0, ''),
(34, 1, '001', 'CABO ACELERADOR FS 160 NOVO(359)', 'STIHL', 'Unid', '8.50', '48.00', 0.00, 10, '001', 0, 0, ''),
(35, 1, '001', 'CABO ACELERADOR 226R/236R/143', 'HUSQVARNA', 'Unid', '19.90', '85.00', 0.00, 10, '001', 0, 0, ''),
(36, 1, '001', 'CABO ACELERADOR KA 85', 'STIHL', 'Unid', '4.40', '22.00', 0.00, 10, '001', 0, 0, ''),
(37, 1, '001', 'CABO DO ACELERADOR FS 85', 'STIHL', 'Unid', '7.90', '48.00', 0.00, 10, '001', 0, 0, ''),
(38, 1, '123', 'DIVERSOS', 'MARCA', 'Unid', '0.00', '0.00', 0.00, 10, '000', 0, 0, ''),
(39, 1, '001', 'CAMARA JACTO', 'JACTO', 'Unid', '93.00', '135.00', 0.00, 10, '001', 0, 0, ''),
(40, 1, '001', 'CANECA NOGUEIRA 6.5', 'NOGUEIRA', 'Unid', '65.00', '130.00', 0.00, 10, '001', 0, 0, ''),
(41, 1, '001', 'CANECA NOGUEIRA 800  (220V)', 'NOGUEIRA', 'Unid', '62.00', '130.00', 0.00, 10, '001', 0, 0, ''),
(42, 1, '001', 'CANECA NOGUEIRA 900(125V)', 'NOGUEIRA', 'Unid', '62.00', '135.00', 0.00, 10, '01', 0, 0, ''),
(43, 1, '001', 'CANECA NOGUEIRA 6.5 (220V)', 'NOGUEIRA', 'Unid', '62.00', '135.00', 0.00, 10, '001', 0, 0, ''),
(44, 1, '001', 'CANECA NOGUEIRA 800(220V)', 'NOGUEIRA', 'Unid', '62.00', '135.00', 0.00, 10, '001', 0, 0, ''),
(45, 1, '001', 'CANECA NOGUEIRA 900(220V)', 'NOGUEIRA', 'Unid', '62.00', '135.00', 0.00, 10, '01', 0, 0, ''),
(46, 1, '001', 'CANOPLA NOGUEIRA 6.5', 'NOGUEIRA', 'Unid', '9.00', '25.00', 0.00, 10, '001', 0, 0, ''),
(47, 1, '001', 'CANOPLA NOGUEIRA 800/900', 'NOGUEIRA', 'Unid', '9.00', '25.00', 0.00, 10, '001', 0, 0, ''),
(48, 1, '001', 'CAPA CARBURADO C 230', 'SHINDAIWA', 'Unid', '5.90', '15.00', 0.00, 10, '001', 0, 0, ''),
(49, 1, '001', 'CAPA CARBURADOR KA 85', 'STIHL', 'Unid', '6.12', '15.00', 0.00, 10, '001', 0, 0, ''),
(50, 1, '001', 'CARBURADOR MS 170 (1130-120-0606)', 'STIHL', 'Unid', '101.00', '156.00', 0.00, 10, '001', 0, 0, ''),
(51, 1, '001', 'CARBURADOR BG 86(4241-120-0613)', 'STIHL', 'Unid', '115.00', '160.00', 0.00, 10, '001', 0, 0, ''),
(52, 1, '001', 'CARBURADOR BR 600(4282-120-0611)', 'STIHL', 'Unid', '97.10', '198.00', 0.00, 10, '001', 0, 0, ''),
(53, 1, '001', 'CARBURADOR HUSQVARNA 226 RJ', 'HUSQVARNA', 'Unid', '79.00', '160.00', 0.00, 10, '001', 0, 0, ''),
(54, 1, '001', 'CARBURADOR KA 120(4137-120-0623)', 'STIHL', 'Unid', '111.27', '170.00', 0.00, 10, '001', 0, 0, ''),
(55, 1, '001', 'CARBURADOR KA 85(4137-120-0629)', 'STIHL', 'Unid', '94.20', '145.00', 0.00, 10, '001', 0, 0, ''),
(56, 1, '001', 'CARBURADOR FS 160/220', 'STIHL', 'Unid', '139.00', '259.00', 0.00, 10, '01', 0, 0, ''),
(57, 1, '001', 'CARCAÇA DO VENTILADOR(1127-080-1802)', 'STIHL', 'Unid', '65.00', '112.00', 0.00, 10, '001', 0, 0, ''),
(58, 1, '001', 'CARCAÇA FILTRO KA(4137-140-2802)', 'STIHL', 'Unid', '25.00', '37.50', 0.00, 10, '001', 0, 0, ''),
(59, 1, '001', 'CARRETEL DE NYLON FS 160/220', 'ANDRADAS', 'Unid', '22.00', '55.00', 0.00, 10, '001', 0, 0, ''),
(60, 1, '001', 'CARRETEL NYLON FS 85/KA 85', 'ANDRADAS', 'Unid', '22.00', '48.00', 0.00, 10, '001', 0, 0, ''),
(61, 1, '001', 'CATRACA  DE PARTIDA C230', 'SHINDAIWA', 'Unid', '17.00', '30.00', 0.00, 10, '001', 0, 0, ''),
(62, 1, '001', 'CHAPA MOTOSSERRA 272', 'HUSQVARNA', 'Unid', '10.80', '22.00', 0.00, 10, '001', 0, 0, ''),
(63, 1, '001', 'CILINDRO 226 RJ', 'HUSQVARNA', 'Unid', '128.00', '230.00', 0.00, 10, '001', 0, 0, ''),
(64, 1, '001', 'CILINDRO PISTAO BR 420', 'STIHL', 'Unid', '390.00', '585.00', 0.00, 10, '001', 0, 0, ''),
(65, 1, '001', 'CILINDRO PISTAO MS 61', 'HUSQVARNA', 'Unid', '130.00', '258.00', 0.00, 10, '001', 0, 0, ''),
(66, 1, '001', 'CONEXAO MANGUEIRA C230(3087)', 'SHINDAIWA', 'Unid', '17.00', '38.00', 0.00, 10, '001', 0, 0, ''),
(67, 1, '001', 'CONEXAO MAGUEIRA 226 RJ', 'HUSQVARNA', 'Unid', '7.90', '22.00', 0.00, 10, '001', 0, 0, ''),
(68, 1, '001', 'CORDAO PARTIDA ROCADEIRAS', 'ANDRADAS', 'Unid', '1.47', '5.00', 0.00, 10, '001', 0, 0, ''),
(69, 1, '001', 'COROA E PINHAO C230', 'SHINDAIWA', 'Unid', '59.90', '132.00', 0.00, 10, '001', 0, 0, ''),
(70, 1, '001', 'CORPO DO FILTRO DE AR C230', 'SHINDAIWA', 'Unid', '24.84', '38.00', 0.00, 10, '001', 0, 0, ''),
(71, 1, '001', 'CORRENTE MS 170', 'STIHL', 'Unid', '2.50', '1.39', 0.00, 10, '001', 0, 0, ''),
(72, 1, '001', 'CORRENTE MS 250', 'STIHL', 'Unid', '2.50', '1.45', 0.00, 10, '001', 0, 0, ''),
(73, 1, '001', 'CORRENTE ORIGON', 'ORIGON', 'Unid', '2.10', '1.39', 0.00, 10, '001', 0, 0, ''),
(74, 1, '001', 'DISCO DE VIDIA NAKASHI', 'NAKASCHI', 'Unid', '36.00', '55.00', 0.00, 10, '001', 0, 0, ''),
(75, 1, '001', 'EIXO CARDAN CURTO C230', 'SHINDAIWA', 'Unid', '16.00', '40.00', 0.00, 10, '001', 0, 0, ''),
(76, 1, '001', 'EIXO CARDAN LONGO C230', 'SHINDAIWA', 'Unid', '19.00', '40.00', 0.00, 10, '001', 0, 0, ''),
(77, 1, '001', 'EIXO CARDAN LONGO C230/KA 85', '', 'Unid', '24.00', '57.00', 0.00, 10, '001', 0, 0, ''),
(78, 1, '001', 'EIXO CARDAN CURTO KA 85', '', 'Unid', '21.00', '48.00', 0.00, 10, '001', 0, 0, ''),
(79, 1, '001', 'EIXO CARDAN CURTO KA 85/C 230', '', 'Unid', '55.00', '24.00', 0.00, 10, '001', 0, 0, ''),
(80, 1, '001', 'EIXO CARDAN HUSQVARNA 143', 'HUSQVARNA', 'Unid', '78.00', '42.00', 0.00, 10, '001', 0, 0, ''),
(81, 1, '001', 'EIXO CARDAN LONGO C 230/NAKACHI', '', 'Unid', '68.00', '24.00', 0.00, 10, '001', 0, 0, ''),
(82, 1, '001', 'EIXO CARDAN LONGO KA 85', 'STIHL', 'Unid', '58.00', '21.00', 0.00, 10, '001', 0, 0, ''),
(83, 1, '001', 'EIXO CARAN LONGO 226RJ/C 230', '', 'Unid', '68.00', '24.00', 0.00, 10, '001', 0, 0, ''),
(84, 1, '001', 'EIXO DA BIELA DCM 11 BRUDDEN', 'BRUDDEN', 'Unid', '10.00', '32.00', 0.00, 10, '001', 0, 0, ''),
(85, 1, '001', 'EIXO CARDAN LONGO KA 85/C 230', '', 'Unid', '58.00', '24.00', 0.00, 10, '001', 0, 0, ''),
(86, 1, '001', 'ELO DE PRISIONEIRO DA DCM 11', '', 'Unid', '12.00', '3.60', 0.00, 10, '001', 0, 0, ''),
(87, 1, '001', 'ELO DE EMENDA NAKASHI', '', 'Unid', '7.00', '1.90', 0.00, 10, '001', 0, 0, ''),
(88, 1, '001', 'ELA DE EMENDA DCM 12', '', 'Unid', '12.00', '3.90', 0.00, 10, '001', 0, 0, ''),
(89, 1, '001', 'ENGATE DA CATRACA C230', 'SHINDAIWA', 'Unid', '14.00', '6.90', 0.00, 10, '001', 0, 0, ''),
(90, 1, '001', 'DESCARBONIZACAO', '', 'Unid', '25.00', '12.00', 0.00, 10, '001', 0, 0, ''),
(91, 1, '001', 'DESCARBONIZACAO', '', 'Unid', '25.00', '12.00', 0.00, 10, '001', 0, 0, ''),
(92, 1, '001', 'MOLA ASPIRAL DE PARTIDA  KA 85/C 230', 'STIHL', 'Unid', '5.90', '22.00', 0.00, 10, '001', 0, 0, ''),
(93, 1, '093', 'teste', 'teste', 'Unid', '2.00', '1.00', 0.00, 10, 'teste', 0, 0, ''),
(94, 1, '001', 'FILTRO DE AR BR 420 (4203-141-0301)', 'STIHL', 'Unid', '38.00', '58.00', 0.00, 10, '001', 0, 0, ''),
(95, 1, '001', 'GABINETE DCM 11', 'BRUDDEN', 'Unid', '54.59', '95.00', 0.00, 10, '001', 0, 0, ''),
(96, 1, '001', 'CONJUNTO DE PINHAO DCM 11/12', 'BRUDDEN', 'Unid', '54.00', '104.00', 0.00, 10, '001', 0, 0, ''),
(97, 1, '001', 'OLEO STIHL8017 500ML (0781-389-3004)', 'STIHL', 'Unid', '18.30', '22.00', 0.00, 10, '001', 0, 0, ''),
(98, 1, '001', 'LUVA MAGUEIRA GASOLINA FS 85(0000-989-0516)', 'STIHL', 'Unid', '3.25', '8.00', 0.00, 10, '001', 0, 0, ''),
(99, 1, '001', 'PISTAO 226', 'HUSQVARNA', 'Unid', '50.20', '75.00', 0.00, 10, '001', 0, 0, ''),
(100, 1, '001', 'GATILHO JACTO', 'JACTO', 'Unid', '3.30', '6.50', 0.00, 10, '001', 0, 0, ''),
(101, 1, '001', 'GAXETA JACTO', 'JACTO', 'Unid', '1.10', '2.20', 0.00, 10, '001', 0, 0, ''),
(102, 1, '001', 'HASTE DIREITA DCM 11', '', 'Unid', '20.61', '37.00', 0.00, 10, '001', 0, 0, ''),
(103, 1, '001', 'HASTE DIREITA DUPLA ', '', 'Unid', '31.00', '54.00', 0.00, 10, '001', 0, 0, ''),
(104, 1, '001', 'HASTE ESQ COMPL PS', '', 'Unid', '35.61', '56.00', 0.00, 10, '001', 0, 0, ''),
(105, 1, '001', 'HASTE ESQUERDA DUPLA', '', 'Unid', '52.00', '90.00', 0.00, 10, '001', 0, 0, ''),
(106, 1, '001', 'INTERRUPITOR KA 4137-182-1701', '', 'Unid', '7.00', '17.00', 0.00, 10, '001', 0, 0, ''),
(107, 1, '001', 'ISOLADOR FLANGLE 226', '', 'Unid', '13.50', '27.00', 0.00, 10, '001', 0, 0, ''),
(108, 1, '001', 'JOGO DE ARRUELA E TRAVA JACTO', '', 'Unid', '1.60', '3.20', 0.00, 10, '001', 0, 0, ''),
(109, 1, '001', 'JOGO DE ARRUELA E CONTRAPINO JACTO', '', 'Unid', '1.80', '3.60', 0.00, 10, '001', 0, 0, ''),
(110, 1, '001', 'JOGO DE JUNTAS C 230', '', 'Unid', '6.50', '12.00', 0.00, 10, '001', 0, 0, ''),
(111, 1, '001', 'JUNTA CARBURADOR 226 RJ', '', 'Unid', '0.80', '2.00', 0.00, 10, '001', 0, 0, ''),
(112, 1, '001', 'JUNTA CILINDRO BR 420', '', 'Unid', '6.00', '14.50', 0.00, 10, '001', 0, 0, ''),
(113, 1, '001', 'JUNTA DE CILINDRO KA 85 (225) ANDR', '', 'Unid', '0.75', '15.00', 0.00, 10, '001', 0, 0, ''),
(114, 1, '001', 'JUNTA CILINDRO ROÇADEIRA 226 RJ (4937) ANDR ', '', 'Unid', '3.83', '10.00', 0.00, 10, '001', 0, 0, ''),
(115, 1, '001', 'JUNTA DO ISOLADOR FLANGE 226 RJ (6464)', '', 'Unid', '3.90', '10.00', 0.00, 10, '001', 0, 0, ''),
(116, 1, '001', 'JUNTA DO SILENCIADOR C230 (3469) ANDR', '', 'Unid', '4.40', '20.00', 0.00, 10, '001', 0, 0, ''),
(117, 1, '001', 'JUNTA DO SILENCIADOR KA85 (509) ANDR ', '', 'Unid', '5.90', '17.50', 0.00, 10, '001', 0, 0, ''),
(118, 1, '001', 'KIT ANEL VEDAÇAO BOMBA NOG 6.Q ', '', 'Unid', '0.70', '2.50', 0.00, 10, '001', 0, 0, ''),
(119, 1, '001', 'KIT ANEL VEDAÇAO BOMBA NOG 8/9', '', 'Unid', '0.70', '2.50', 0.00, 10, '001', 0, 0, ''),
(120, 1, '001', 'LIMA 5/32 ', '', 'Unid', '4.16', '8.00', 0.00, 10, '001', 0, 0, ''),
(121, 1, '001', 'LIMA 7/32 ', '', 'Unid', '4.16', '9.00', 0.00, 10, '001', 0, 0, ''),
(122, 1, '001', 'LIMITADOR KA160 / KA85 (29) ANDR', '', 'Unid', '4.40', '10.00', 0.00, 10, '001', 0, 0, ''),
(123, 1, '001', 'LUVA TANQUE KA 85 0000-989-0516', '', 'Unid', '3.50', '7.00', 0.00, 10, '001', 0, 0, ''),
(124, 1, '001', 'MARTELETE 650 ', '', 'Unid', '22.00', '40.70', 0.00, 10, '001', 0, 0, ''),
(125, 1, '001', 'MARTELETE 800/900', '', 'Unid', '24.00', '45.00', 0.00, 10, '001', 0, 0, ''),
(126, 1, '001', 'MISTURADOR DE GASOLINA (1065) ANDR ', '', 'Unid', '5.20', '15.00', 0.00, 10, '001', 0, 0, ''),
(127, 1, '001', 'MODULO IGNIÇÃO KA85 (3794)', '', 'Unid', '109.00', '140.00', 0.00, 10, '001', 0, 0, ''),
(128, 1, '001', 'MOLA CARBURADOR 1123-122-3000', '', 'Unid', '6.00', '18.00', 0.00, 10, '001', 0, 0, ''),
(129, 1, '001', 'OCULOS DE TELA', '', 'Unid', '5.90', '8.00', 0.00, 10, '001', 0, 0, ''),
(130, 1, '001', 'OCULOS INCOLOR ', '', 'Unid', '3.50', '6.00', 0.00, 10, '001', 0, 0, ''),
(131, 1, '001', 'OLEO STHIL 8017 0781-389-3004', '', 'Unid', '17.50', '22.00', 0.00, 10, '001', 0, 0, ''),
(132, 1, '001', 'PEÇA DE ENGATE FS 85 (1543) ANDR ', '', 'Unid', '5.50', '12.00', 0.00, 10, '001', 0, 0, ''),
(133, 1, '001', 'PISTÃO 226', '', 'Unid', '50.20', '75.50', 0.00, 10, '001', 0, 0, ''),
(134, 1, '001', 'ROLAMENTO 6000', '', 'Unid', '4.50', '15.00', 0.00, 10, '001', 0, 0, ''),
(135, 1, '001', 'ROLAMENTO  6001 ', '', 'Unid', '4.50', '15.00', 0.00, 10, '001', 0, 0, ''),
(136, 1, '001', 'ROLAMENTO 6002 HS 82', '', 'Unid', '13.00', '26.00', 0.00, 10, '001', 0, 0, ''),
(137, 1, '001', 'ROLAMENTO 609', '', 'Unid', '4.50', '12.00', 0.00, 10, '001', 0, 0, ''),
(138, 1, '001', 'ROLAMENTO 6201', '', 'Unid', '3.90', '14.00', 0.00, 10, '001', 0, 0, ''),
(139, 1, '001', 'ROLAMENTO 6202', '', 'Unid', '16.00', '22.00', 0.00, 10, '001', 0, 0, ''),
(140, 1, '001', 'ROLAMENTO 626', '', 'Unid', '2.70', '14.00', 0.00, 10, '001', 0, 0, ''),
(141, 1, '001', 'ROLAMENTO 6900 D ', '', 'Unid', '3.50', '15.00', 0.00, 10, '001', 0, 0, ''),
(142, 1, '001', 'ROLAMENTO DCM 11 608', '', 'Unid', '4.50', '15.00', 0.00, 10, '001', 0, 0, ''),
(143, 1, '001', 'ROLETE 3/8  7 (124) ANDR ', '', 'Unid', '11.80', '32.00', 0.00, 10, '001', 0, 0, ''),
(144, 1, '001', 'ROSCA 5 mm1', '', 'Unid', '1.00', '15.00', 0.00, 10, '001', 0, 0, ''),
(145, 1, '001', 'SABRE MS 170/250 HUSQ 236 (9772) ANDR ', '', 'Unid', '42.00', '132.00', 0.00, 10, '001', 0, 0, ''),
(146, 1, '001', 'SUPORTE DAS HASTE DCM 11', '', 'Unid', '15.72', '35.00', 0.00, 10, '001', 0, 0, ''),
(147, 1, '001', 'SUPORTE DCM 12 DUPLA ', '', 'Unid', '18.92', '37.00', 0.00, 10, '001', 0, 0, ''),
(148, 1, '001', 'TAMBOR DA EMBREAGEM FS85 SP81 KA85', '', 'Unid', '30.00', '61.00', 0.00, 10, '001', 0, 0, ''),
(149, 1, '001', 'TAMBOR DA ENGRENAGEM HS81R 4237-160-2901', '', 'Unid', '60.00', '95.00', 0.00, 10, '001', 0, 0, ''),
(150, 1, '001', 'TAMBOR DA PARTIDA RETRATIL C230', '', 'Unid', '20.66', '35.00', 0.00, 10, '001', 0, 0, ''),
(151, 1, '001', 'TAMBOR EMBREAGEM C230', '', 'Unid', '26.00', '57.00', 0.00, 10, '001', 0, 0, ''),
(152, 1, '001', 'TAMBOR EMBREAGEM HUSQ 226', '', 'Unid', '28.00', '68.00', 0.00, 10, '001', 0, 0, ''),
(153, 1, '001', 'TUBO EIXO 226', '', 'Unid', '50.00', '100.00', 0.00, 10, '001', 0, 0, ''),
(154, 1, '001', 'TUBO EIXO C230', '', 'Unid', '49.00', '98.00', 0.00, 10, '001', 0, 0, ''),
(155, 1, '001', 'VALVULA 650', '', 'Unid', '2.00', '7.00', 0.00, 10, '001', 0, 0, ''),
(156, 1, '001', 'VALVULA 800/900', '', 'Unid', '2.00', '8.00', 0.00, 10, '001', 0, 0, ''),
(157, 1, '001', 'VELA DE IGNIÇÃO BPM(128) ANDR', '', 'Unid', '9.90', '22.00', 0.00, 10, '001', 0, 0, ''),
(158, 1, '001', 'VENTOSA 4G 800/900', '', 'Unid', '4.70', '13.00', 0.00, 10, '001', 0, 0, ''),
(159, 1, '001', 'TUBO DO EIXO 226 ORIGINAL', 'HUSQUVARNA', 'Unid', '90.00', '180.00', 0.00, 10, '01', 0, 0, ''),
(160, 1, '001', 'VIRABREQUIM USINADO DCM 11/12', 'BRUDDEN', 'Unid', '40.69', '75.00', 0.00, 10, '001', 0, 0, '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos_orcamento`
--

DROP TABLE IF EXISTS `produtos_orcamento`;
CREATE TABLE IF NOT EXISTS `produtos_orcamento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orcamento` int(10) UNSIGNED NOT NULL,
  `id_produto` int(11) UNSIGNED NOT NULL,
  `descricao` varchar(255) CHARACTER SET utf8 NOT NULL,
  `localizacao` varchar(25) CHARACTER SET utf8 NOT NULL,
  `preco_venda` decimal(6,2) NOT NULL,
  `qtde` int(11) UNSIGNED NOT NULL,
  `desconto` decimal(6,2) NOT NULL,
  `total_item` decimal(6,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orcamentos_has_produtos_FKIndex1` (`id_orcamento`),
  KEY `orcamentos_has_produtos_FKIndex2` (`id_produto`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `produtos_orcamento`
--

INSERT INTO `produtos_orcamento` (`id`, `id_orcamento`, `id_produto`, `descricao`, `localizacao`, `preco_venda`, `qtde`, `desconto`, `total_item`) VALUES
(1, 1, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(2, 1, 1, 'ABAFADOR K40', '00', '10.97', 3, '0.00', '32.91'),
(4, 2, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(5, 3, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(6, 4, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(7, 4, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(8, 4, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(9, 4, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(10, 4, 1, 'ABAFADOR K40', '00', '10.97', 1, '0.00', '10.97'),
(15, 9, 38, 'DIVERSOS', '000', '0.00', 1, '0.00', '0.00'),
(12, 6, 3, 'GRAXA NA MAOZINHA', '001', '5.00', 1, '0.00', '5.00'),
(16, 10, 38, 'DIVERSOS', '000', '0.00', 1, '0.00', '0.00'),
(17, 11, 38, 'DIVERSOS', '000', '0.00', 1, '0.00', '0.00'),
(18, 12, 38, 'DIVERSOS', '000', '0.00', 1, '0.00', '0.00'),
(19, 13, 38, 'DIVERSOS', '000', '0.00', 1, '0.00', '0.00'),
(20, 14, 38, 'DIVERSOS', '000', '0.00', 1, '0.00', '0.00'),
(22, 15, 90, 'DESCARBONIZACAO', '001', '12.00', 1, '0.00', '12.00'),
(23, 1, 2, 'ACELERADOR COMPLETO C 230', '2552', '117.00', 1, '0.00', '117.00'),
(24, 1, 28, 'BUCHA DO CANO 226RJ', '001', '9.50', 1, '0.00', '9.50'),
(25, 16, 92, 'MOLA ASPIRAL DE PARTIDA  KA 85/C 230', '001', '5.90', 1, '0.00', '5.90'),
(28, 17, 1, 'ABAFADOR K40', '00', '20.00', 1, '0.00', '20.00'),
(29, 17, 3, 'GRAXA NA MAOZINHA', '001', '5.00', 1, '0.00', '5.00'),
(30, 17, 83, 'EIXO CARAN LONGO 226RJ/C 230', '001', '24.00', 1, '0.00', '24.00'),
(31, 17, 59, 'CARRETEL DE NYLON FS 160/220', '001', '22.00', 1, '0.00', '22.00'),
(32, 17, 8, 'AMORTECEDOR BOMBA  6.50', '001', '22.00', 3, '0.00', '66.00'),
(33, 18, 92, 'MOLA ASPIRAL DE PARTIDA  KA 85/C 230', '001', '5.90', 1, '0.00', '5.90'),
(34, 18, 2, 'ACELERADOR COMPLETO C 230', '2552', '117.00', 2, '0.00', '234.00'),
(35, 19, 3, 'GRAXA NA MAOZINHA', '001', '25.00', 1, '0.00', '25.00'),
(36, 21, 96, 'CONJUNTO DE PINHAO DCM 11/12', '001', '104.00', 1, '0.00', '104.00'),
(37, 25, 63, 'CILINDRO 226 RJ', '001', '230.00', 1, '0.00', '230.00'),
(39, 25, 11, 'ANEL DE COMPRESAO 226 RJ', '001', '19.00', 2, '0.00', '38.00'),
(40, 25, 99, 'PISTAO 226', '001', '75.00', 1, '0.00', '75.00'),
(41, 25, 97, 'OLEO STIHL8017 500ML (0781-389-3004)', '001', '22.00', 1, '0.00', '22.00'),
(45, 26, 52, 'CARBURADOR BR 600(4282-120-0611)', '001', '198.00', 1, '0.00', '198.00'),
(47, 28, 55, 'CARBURADOR KA 85(4137-120-0629)', '001', '145.00', 1, '0.00', '145.00'),
(48, 28, 106, 'INTERRUPITOR KA 4137-182-1701', '001', '17.00', 1, '0.00', '17.00'),
(49, 30, 63, 'CILINDRO 226 RJ', '001', '230.00', 1, '0.00', '230.00'),
(50, 30, 133, 'PISTÃO 226', '001', '75.50', 1, '0.00', '75.50'),
(52, 30, 11, 'ANEL DE COMPRESAO 226 RJ', '001', '19.00', 2, '0.00', '38.00'),
(53, 30, 114, 'JUNTA CILINDRO ROÇADEIRA 226 RJ (4937) ANDR ', '001', '10.00', 1, '0.00', '10.00'),
(54, 30, 95, 'GABINETE DCM 11', '001', '95.00', 1, '0.00', '95.00'),
(55, 30, 159, 'TUBO DO EIXO 226 ORIGINAL', '01', '180.00', 1, '0.00', '180.00'),
(56, 30, 84, 'EIXO DA BIELA DCM 11 BRUDDEN', '001', '32.00', 1, '0.00', '32.00'),
(57, 31, 95, 'GABINETE DCM 11', '001', '95.00', 1, '0.00', '95.00'),
(58, 32, 95, 'GABINETE DCM 11', '001', '95.00', 1, '0.00', '95.00'),
(68, 38, 158, 'VENTOSA 4G 800/900', '001', '13.00', 1, '0.00', '13.00'),
(62, 34, 159, 'TUBO DO EIXO 226 ORIGINAL', '01', '180.00', 1, '0.00', '180.00'),
(63, 35, 134, 'ROLAMENTO 6000', '001', '15.00', 1, '0.00', '15.00'),
(64, 35, 137, 'ROLAMENTO 609', '001', '12.00', 1, '0.00', '12.00'),
(65, 35, 84, 'EIXO DA BIELA DCM 11 BRUDDEN', '001', '32.00', 1, '0.00', '32.00'),
(66, 33, 160, 'VIRABREQUIM USINADO DCM 11/12', '001', '75.00', 1, '0.00', '75.00'),
(67, 33, 134, 'ROLAMENTO 6000', '001', '15.00', 1, '0.00', '15.00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `recebimento`
--

DROP TABLE IF EXISTS `recebimento`;
CREATE TABLE IF NOT EXISTS `recebimento` (
  `id_recebimento` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_parcelamento` int(11) UNSIGNED NOT NULL,
  `valor` double(6,2) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `forma` varchar(15) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_recebimento`,`id_parcelamento`),
  KEY `recebimento_FKIndex1` (`id_parcelamento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos`
--

DROP TABLE IF EXISTS `servicos`;
CREATE TABLE IF NOT EXISTS `servicos` (
  `id_servico` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) CHARACTER SET utf8 NOT NULL,
  `tempo_minutos` int(11) UNSIGNED DEFAULT NULL,
  `valor` double(6,2) NOT NULL,
  `desconto` double(6,2) NOT NULL,
  PRIMARY KEY (`id_servico`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `servicos`
--

INSERT INTO `servicos` (`id_servico`, `descricao`, `tempo_minutos`, `valor`, `desconto`) VALUES
(1, 'LIMPEZA DE CARBURADOR', 30, 40.00, 0.00),
(2, 'MAO DE OBRA', 30, 75.00, 0.00),
(3, 'DESCARBONIZAÇAO ', 0, 25.00, 0.00),
(4, 'MAO DE OBRA', 30, 45.00, 0.00),
(5, 'GRAXA PARA MAOZINHA', 30, 25.00, 0.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos_orcamento`
--

DROP TABLE IF EXISTS `servicos_orcamento`;
CREATE TABLE IF NOT EXISTS `servicos_orcamento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orcamento` int(10) UNSIGNED NOT NULL,
  `id_servico` int(11) UNSIGNED NOT NULL,
  `descricao` varchar(255) CHARACTER SET utf8 NOT NULL,
  `valor` decimal(6,2) NOT NULL,
  `qtde` int(11) UNSIGNED NOT NULL,
  `desconto` decimal(6,2) NOT NULL,
  `total_item` decimal(6,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orcamentos_has_servicos_FKIndex1` (`id_orcamento`),
  KEY `orcamentos_has_servicos_FKIndex2` (`id_servico`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `servicos_orcamento`
--

INSERT INTO `servicos_orcamento` (`id`, `id_orcamento`, `id_servico`, `descricao`, `valor`, `qtde`, `desconto`, `total_item`) VALUES
(1, 1, 1, 'LIMPEZA DE CARBURADOR', '40.00', 1, '0.00', '40.00'),
(3, 3, 1, 'LIMPEZA DE CARBURADOR', '40.00', 1, '0.00', '40.00'),
(4, 4, 1, 'LIMPEZA DE CARBURADOR', '40.00', 1, '0.00', '40.00'),
(5, 4, 1, 'LIMPEZA DE CARBURADOR', '40.00', 1, '0.00', '40.00'),
(6, 4, 1, 'LIMPEZA DE CARBURADOR', '40.00', 1, '0.00', '40.00'),
(7, 6, 1, 'LIMPEZA DE CARBURADOR', '40.00', 1, '0.00', '40.00'),
(9, 1, 2, 'MAO DE OBRA', '75.00', 1, '0.00', '75.00'),
(12, 1, 3, 'DESCARBONIZAÇAO ', '25.00', 1, '0.00', '25.00'),
(13, 17, 2, 'MAO DE OBRA', '75.00', 1, '0.00', '75.00'),
(14, 19, 4, 'MAO DE OBRA', '45.00', 1, '0.00', '45.00'),
(15, 20, 2, 'MAO DE OBRA', '75.00', 1, '0.00', '75.00'),
(16, 23, 5, 'TRASMISAO KA 85', '150.00', 1, '0.00', '150.00'),
(17, 26, 2, 'MAO DE OBRA', '75.00', 1, '0.00', '75.00'),
(18, 30, 2, 'MAO DE OBRA', '75.00', 1, '0.00', '75.00'),
(19, 30, 5, 'GRAXA PARA MAOZINHA', '25.00', 1, '0.00', '25.00'),
(20, 31, 5, 'GRAXA PARA MAOZINHA', '25.00', 1, '0.00', '25.00'),
(21, 32, 5, 'GRAXA PARA MAOZINHA', '25.00', 1, '0.00', '25.00'),
(23, 33, 4, 'MAO DE OBRA', '45.00', 1, '0.00', '45.00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(25) NOT NULL,
  `senha` varchar(10) NOT NULL,
  `perfil` varchar(15) NOT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `vendas`
--

DROP TABLE IF EXISTS `vendas`;
CREATE TABLE IF NOT EXISTS `vendas` (
  `id_venda` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_recebimento` int(11) UNSIGNED NOT NULL,
  `id_parcelamento` int(11) UNSIGNED NOT NULL,
  `total_venda` double(6,2) NOT NULL,
  `data_hora` datetime NOT NULL,
  `status` varchar(25) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_venda`,`id_cliente`,`id_usuario`,`id_recebimento`,`id_parcelamento`),
  KEY `vendas_FKIndex1` (`id_cliente`),
  KEY `vendas_FKIndex2` (`id_usuario`),
  KEY `vendas_FKIndex3` (`id_recebimento`,`id_parcelamento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
